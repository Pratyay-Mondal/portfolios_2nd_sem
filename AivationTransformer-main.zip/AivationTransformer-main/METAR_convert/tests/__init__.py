"""
METAR_convert Tests Module

This module contains all test and example files for the METAR_convert package.
All test files use sys.path manipulation to import from the parent package.
"""

__version__ = '1.0.0'
