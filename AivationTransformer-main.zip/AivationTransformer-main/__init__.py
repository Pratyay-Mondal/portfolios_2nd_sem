"""
Package initialization for Aviation Weather Transformer
"""
